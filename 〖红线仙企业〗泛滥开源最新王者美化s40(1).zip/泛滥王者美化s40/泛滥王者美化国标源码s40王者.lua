function S_Pointer(t_So, t_Offset, _bit)
	local function getRanges()
		local ranges = {}
		local t = gg.getRangesList('^/data/*.so*$')
		for i, v in pairs(t) do
			if v.type:sub(2, 2) == 'w' then
				table.insert(ranges, v)
			end
		end
		return ranges
	end
	local function Get_Address(N_So, Offset, ti_bit)
		local ti = gg.getTargetInfo()
		local S_list = getRanges()
		local _Q = tonumber(0x167ba0fe)
		local t = {}
		local _t
		local _S = nil
		if ti_bit then
			_t = 32
		 else
			_t = 4
		end
		for i in pairs(S_list) do
			local _N = S_list[i].internalName:gsub('^.*/', '')
			if N_So[1] == _N and N_So[2] == S_list[i].state then
				_S = S_list[i]
				break
			end
		end
		if _S then
			t[#t + 1] = {}
			t[#t].address = _S.start + Offset[1]
			t[#t].flags = _t
			if #Offset ~= 1 then
				for i = 2, #Offset do
					local S = gg.getValues(t)
					t = {}
					for _ in pairs(S) do
						if not ti.x64 then
							S[_].value = S[_].value & 0xFFFFFFFF
						end
						t[#t + 1] = {}
						t[#t].address = S[_].value + Offset[i]
						t[#t].flags = _t
					end
				end
			end
			_S = t[#t].address
		end
		return _S
	end
	local _A = string.format('0x%X', Get_Address(t_So, t_Offset, _bit))
	return _A
end--枫奉泛滥王者美化主页源码 持续泛滥加载界面国标--枫奉泛滥王者美化主页源码 持续泛滥加载界面国标枫奉泛滥王者美化主页源码 持续泛滥加载界面国标枫奉泛滥王者美化主页源码 持续泛滥加载界面国标
--枫奉泛滥王者美化主页源码 持续泛滥加载界面国标枫奉泛滥王者美化主页源码 持续泛滥加载界面国标枫奉泛滥王者美化主页源码 持续泛滥加载界面国标
while( true )
do
local t = {"libil2cpp.so:bss", "Cb"}--加载界面称号
local tt = {0xE60,0xB8,0x4E0,0x50,0x158}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = 208}})

local t = {"libil2cpp.so:bss", "Cb"}--加载界面巅峰框
local tt = {0xE60,0xB8,0x4E0,0x50,0x21C}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = 1}})

local t = {"libil2cpp.so:bss", "Cb"}--加载界面头像框
local tt = {0xE60,0xB8,0x4E0,0x50,0x03C}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = 9701}})


local t = {"libil2cpp.so:bss", "Cb"}--加载界面国标
local tt = {0xE60,0xB8,0x4E0,0x50,0x150}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = 4}})

local t = {"libil2cpp.so:bss", "Cb"}--加载界面国标排名
local tt = {0xE60,0xB8,0x4E0,0x50,0x154}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = 1}})--默认1即可

local t = {"libil2cpp.so:bss", "Cb"}--加载界面。贵族。
local tt = {0x1468,0x470,0xB48,0x320,0x50,0x80,0x14}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = 12}})--
end
--枫奉泛滥王者美化主页源码 持续泛滥加载界面国标枫奉泛滥王者美化主页源码 持续泛滥加载界面国标枫奉泛滥王者美化主页源码 持续泛滥加载界面国标枫奉泛滥王者美化主页源码 持续泛滥加载界面国标枫奉泛滥王者美化主页源码 持续泛滥加载界面国标