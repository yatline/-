function S_Pointer(t_So, t_Offset, _bit)
	local function getRanges()
		local ranges = {}
		local t = gg.getRangesList('^/data/*.so*$')
		for i, v in pairs(t) do
			if v.type:sub(2, 2) == 'w' then
				table.insert(ranges, v)
			end
		end
		return ranges
	end
	local function Get_Address(N_So, Offset, ti_bit)
		local ti = gg.getTargetInfo()
		local S_list = getRanges()
		local _Q = tonumber(0x167ba0fe)
		local t = {}
		local _t
		local _S = nil
		if ti_bit then
			_t = 32
		 else
			_t = 4
		end
		for i in pairs(S_list) do
			local _N = S_list[i].internalName:gsub('^.*/', '')
			if N_So[1] == _N and N_So[2] == S_list[i].state then
				_S = S_list[i]
				break
			end
		end
		if _S then
			t[#t + 1] = {}
			t[#t].address = _S.start + Offset[1]
			t[#t].flags = _t
			if #Offset ~= 1 then
				for i = 2, #Offset do
					local S = gg.getValues(t)
					t = {}
					for _ in pairs(S) do
						if not ti.x64 then
							S[_].value = S[_].value & 0xFFFFFFFF
						end
						t[#t + 1] = {}
						t[#t].address = S[_].value + Offset[i]
						t[#t].flags = _t
					end
				end
			end
			_S = t[#t].address
		end
		return _S
	end
	local _A = string.format('0x%X', Get_Address(t_So, t_Offset, _bit))
	return _A
end

-----枫奉泛滥王者美化主页源码     枫奉泛滥王者美化主页源码    枫奉泛滥王者美化主页源码    枫奉泛滥王者美化主页源码 

--枫奉泛滥王者美化主页源码 持续泛滥加载界面国标   枫奉泛滥王者美化主页源码 持续泛滥加载界面国标枫奉泛滥王者美化主页源码 持续泛滥加载界面国标
--枫奉泛滥王者美化主页源码 持续泛滥加载界面国标
a=gg.prompt({"输入称号代码"},{[1]="208"})

local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x1128,0xE0,0x40,0x250,0x100,0x20,0x304}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})

a=gg.prompt({"输入英雄代码"},{[1]="502"})

local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x70A0,0x6F8,0x7C0,0x20,0x6B0}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})

a=gg.prompt({"输入英雄皮肤代码"},{[1]="2"})

local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x70A0,0x6F8,0x7C0,0x20,0x6B4}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})

a=gg.prompt({"输入段位代码"},{[1]="100"})

local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x70A0,0x6F8,0x7C0,0x20,0x4A4}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})

a=gg.prompt({"输入段位代码(默认即可)"},{[1]="528"})

local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x70A0,0x6F8,0x7C0,0x20,0x4A0}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})

a=gg.prompt({"输入段位代码(默认即可)"},{[1]="528"})

local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x70A0,0x6F8,0x7C0,0x20,0x4A8}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})

a=gg.prompt({"输入历史段位代码"},{[1]="100"})

local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x70A0,0x6F8,0x7C0,0x20,0x4Ac}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})

a=gg.prompt({"输入印记代码"},{[1]="100"})

local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x70A0,0x6F8,0x7C0,0x20,0x4D8}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})

a=gg.prompt({"输入国服代码,4(国服),5(小国)3(金标)2(市标)1(省市)"},{[1]="4"})
local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x2EFDC8,0xC98,0x90,0xB50,0x58,0x18}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})

a=gg.prompt({"输入国服英雄代码"},{[1]="502"})

local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x2EFDC8,0xC98,0x90,0xB50,0x58,0x28}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})

a=gg.prompt({"输入国服排行代码"},{[1]="1"})

local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x2EFDC8,0xC98,0x90,0xB50,0x58,0x1C}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})

a=gg.prompt({"输入头像框代码,巅峰头像框(9701)"},{[1]="9701"})

local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x299968,0x5C8,0x190,0xA20,0x18,0x18}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})



a=gg.prompt({"输入背景代码(2018,2017,2016)"},{[1]="1005"})

local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x70A0,0x6F8,0x7C0,0x20,0x658}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})

a=gg.prompt({"输入贵族的等级代码(12)(11)(10)"},{[1]="12"})

local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x299968,0x5C8,0x190,0xA20,0x18,0x14}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})



a=gg.prompt({"是否开启巅峰小魔方"},{[1]="1"})
local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x70A0,0x6F8,0x7C0,0x20,0x4EC}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})

a=gg.prompt({"是否开启巅峰赛"},{[1]="1"})
local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x70A0,0x6F8,0x7C0,0x20,0x4F0}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})


a=gg.prompt({"是否开启巅峰赛"},{[1]="1"})
local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x70A0,0x6F8,0x7C0,0x20,0x51C}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})

a=gg.prompt({"输入星会员等级（15）"},{[1]="15"})

local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x70A0,0x6F8,0x7C0,0x20,0x670}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})


a=gg.prompt({"输入解锁收藏家 1是解锁 0关闭"},{[1]="1"})

local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x70A0,0x6F8,0x7C0,0x20,0x2C4}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})

a=gg.prompt({"输入收藏家品质 3 2 1"},{[1]="3"})

local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x70A0,0x6F8,0x7C0,0x20,0x2C8}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})

a=gg.prompt({"输入收藏家等级"},{[1]="999"})

local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x70A0,0x6F8,0x7C0,0x20,0x2CC}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})


a=gg.prompt({"开启星元皮肤 2是开启 1是关闭(支持星元皮肤的)"},{[1]="2"})

local t = {"libil2cpp.so:bss", "Cb"}
local tt = {0x304EC8,0x2A8,0x110,0x938,0x20}
local ttt = S_Pointer(t, tt, true)
gg.setValues({{address = ttt, flags = 4, value = a[1]*1}})


--枫奉泛滥王者美化主页源码 持续泛滥加载界面国标 枫奉泛滥王者美化主页源码 持续泛滥加载界面国标枫奉泛滥王者美化主页源码 持续泛滥加载界面国标